var classeIDMW_1_1PTEID__Photo =
[
    [ "~PTEID_Photo", "classeIDMW_1_1PTEID__Photo.html#a953680ea334dbba787e286e4458ad1a9", null ],
    [ "PTEID_Photo", "classeIDMW_1_1PTEID__Photo.html#a8c10660929584d5b507fdd441d993e57", null ],
    [ "getphoto", "classeIDMW_1_1PTEID__Photo.html#a3d2b6540fd017e7eed939f78bd461ebd", null ],
    [ "getphotoCbeff", "classeIDMW_1_1PTEID__Photo.html#a5e564d75978d438fb88434e9248b20d1", null ],
    [ "getphotoFacialinfo", "classeIDMW_1_1PTEID__Photo.html#a70eeab43f626bd19dce4dee4a8860d9b", null ],
    [ "getphotoFacialrechdr", "classeIDMW_1_1PTEID__Photo.html#a8028d3888670475b6b7309a95c420619", null ],
    [ "getphotoImageinfo", "classeIDMW_1_1PTEID__Photo.html#a3d270595b5bd6f863ef05a0b03345816", null ],
    [ "getphotoRAW", "classeIDMW_1_1PTEID__Photo.html#ab59deb7040902cbfe14390dea5b83a11", null ]
];