var structPTEID__PIC =
[
    [ "cbeff", "structPTEID__PIC.html#a5203b87ad420d0703525128cbae860df", null ],
    [ "facialinfo", "structPTEID__PIC.html#ab36f91b3117fc424b8216102621e541a", null ],
    [ "facialrechdr", "structPTEID__PIC.html#aed83343440d603db3afce747345e5c34", null ],
    [ "imageinfo", "structPTEID__PIC.html#a78009654a0ee0b4217e79d9bb7c6137f", null ],
    [ "piclength", "structPTEID__PIC.html#aad16457955a73bb786457f12d408a466", null ],
    [ "picture", "structPTEID__PIC.html#ab453821d4a71af099f4c3f3f6391f7cf", null ],
    [ "version", "structPTEID__PIC.html#add653097d31496fc9187c5b13db03657", null ]
];