var searchData=
[
  ['delobject',['delObject',['../classeIDMW_1_1PTEID__Object.html#ac7ce3a4e2c61dc17e8a396f6f602e66d',1,'eIDMW::PTEID_Object::delObject(unsigned long idx)'],['../classeIDMW_1_1PTEID__Object.html#afb56edd203226bd688d3bd6451dd7fbc',1,'eIDMW::PTEID_Object::delObject(void *impl)']]],
  ['dosodcheck',['doSODCheck',['../classeIDMW_1_1PTEID__EIDCard.html#a93f0c49dd518908bebef67d943f99eb4',1,'eIDMW::PTEID_EIDCard']]]
];
