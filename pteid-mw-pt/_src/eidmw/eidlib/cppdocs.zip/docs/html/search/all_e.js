var searchData=
[
  ['verifypin',['verifyPin',['../classeIDMW_1_1PTEID__Pin.html#abc6e7b41462361f206cef4f9794755af',1,'eIDMW::PTEID_Pin::verifyPin()'],['../classeIDMW_1_1PTEID__Pin.html#a607cdb3a73dd5784fab0ab86461de11c',1,'eIDMW::PTEID_Pin::verifyPin(const char *csPin, unsigned long &amp;ulRemaining, bool bShowDlg=true, void *wndGeometry=0)']]]
];
