var searchData=
[
  ['tproxyinfo',['tProxyInfo',['../structtProxyInfo.html',1,'']]]
];
