var searchData=
[
  ['backupobject',['backupObject',['../classeIDMW_1_1PTEID__Object.html#ab2ed4cb22f7bf2e84d8063fd47811ea0',1,'eIDMW::PTEID_Object']]],
  ['begintransaction',['BeginTransaction',['../classeIDMW_1_1PTEID__ReaderContext.html#aaa7f66aa129ae76fd31de2421b5f7ebb',1,'eIDMW::PTEID_ReaderContext']]]
];
