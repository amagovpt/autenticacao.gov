var classeIDMW_1_1PTEID__ScapConnection =
[
    [ "PTEID_ScapConnection", "classeIDMW_1_1PTEID__ScapConnection.html#a506fe9aebe0bba08d5da78dc059ff513", null ],
    [ "~PTEID_ScapConnection", "classeIDMW_1_1PTEID__ScapConnection.html#ac08f01731c53f3492fc45922e7f6168f", null ],
    [ "postSoapRequest", "classeIDMW_1_1PTEID__ScapConnection.html#a52e523ed9dd684dcabb6ed24dfbb234d", null ]
];