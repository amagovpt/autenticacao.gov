var classeIDMW_1_1PTEID__PDFSignature =
[
    [ "PTEID_PDFSignature", "classeIDMW_1_1PTEID__PDFSignature.html#a3b1ddb1663ebd32a854d1daf9554c2a9", null ],
    [ "PTEID_PDFSignature", "classeIDMW_1_1PTEID__PDFSignature.html#a6eca9255dc6c9b457500dbd2106a35c2", null ],
    [ "~PTEID_PDFSignature", "classeIDMW_1_1PTEID__PDFSignature.html#aed009a59a74faf09643cc64f14e4ca0a", null ],
    [ "addToBatchSigning", "classeIDMW_1_1PTEID__PDFSignature.html#a944d9600360040486a2f7bfdd49ea491", null ],
    [ "addToBatchSigning", "classeIDMW_1_1PTEID__PDFSignature.html#a1d01a72da94fb5df786645ad077ff0f5", null ],
    [ "enableSmallSignatureFormat", "classeIDMW_1_1PTEID__PDFSignature.html#ae9a3e1a7afada66bda9d96d567b37a81", null ],
    [ "enableTimestamp", "classeIDMW_1_1PTEID__PDFSignature.html#a9b5b41bcbb5c84b4ced6081572687723", null ],
    [ "getOccupiedSectors", "classeIDMW_1_1PTEID__PDFSignature.html#adbfaf7f1a1f1b2242cb73dda44c708cf", null ],
    [ "getOtherPageCount", "classeIDMW_1_1PTEID__PDFSignature.html#a6c316f213651c8b09a75cdcda4e08c4c", null ],
    [ "getPageCount", "classeIDMW_1_1PTEID__PDFSignature.html#a3d6d614beac2fde576aa2f439bc226f8", null ],
    [ "getPdfSignature", "classeIDMW_1_1PTEID__PDFSignature.html#a6635aa7f4c06c6360aa01cb5554a40f2", null ],
    [ "isLandscapeFormat", "classeIDMW_1_1PTEID__PDFSignature.html#a043702d9cbbf5a1d6db0368f7adff97a", null ],
    [ "setCustomImage", "classeIDMW_1_1PTEID__PDFSignature.html#ae55768246a66929dd263d36c0ce04b5f", null ],
    [ "setCustomImage", "classeIDMW_1_1PTEID__PDFSignature.html#a6a49f5eb0ee634e28e24850fe18535bc", null ],
    [ "setFileSigning", "classeIDMW_1_1PTEID__PDFSignature.html#aafd61b41e37d2ca54c4ec48a18de821d", null ],
    [ "PTEID_EIDCard", "classeIDMW_1_1PTEID__PDFSignature.html#a83baaf810c86b5b6e4026018af5a6fa8", null ]
];