var structPTEID__Certifs =
[
    [ "certificates", "structPTEID__Certifs.html#a9b16203adb442071bff2cedf4d8ea345", null ],
    [ "certificatesLength", "structPTEID__Certifs.html#af6a90d5e5c870ef4f43e0c59ea757e08", null ]
];