var structPTEID__Certif =
[
    [ "certif", "structPTEID__Certif.html#a2a88e172bfce80f735e127df073f92b4", null ],
    [ "certifLabel", "structPTEID__Certif.html#a4e66a055fa41f0e2659eacb5b654ccf8", null ],
    [ "certifLength", "structPTEID__Certif.html#af35e8eee0075c9bd52ef54001ac8d0d5", null ]
];