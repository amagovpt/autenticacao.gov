var structtProxyInfo =
[
    [ "csPassword", "structtProxyInfo.html#a5f812984c42d245db9dfaf0b8df2abd4", null ],
    [ "csProxy", "structtProxyInfo.html#aee99941b503b851ba119eac11e332f41", null ],
    [ "csUserName", "structtProxyInfo.html#a6a7380a6c9a1fe512fbb8c0c33e488d1", null ],
    [ "uiPort", "structtProxyInfo.html#a3c375ba9773758ae754daeae79fec102", null ]
];