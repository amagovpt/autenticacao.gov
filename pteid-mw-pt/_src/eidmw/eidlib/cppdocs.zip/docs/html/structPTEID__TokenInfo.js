var structPTEID__TokenInfo =
[
    [ "label", "structPTEID__TokenInfo.html#adda5e6a8d9eeb75678ce9a0e1928236f", null ],
    [ "serial", "structPTEID__TokenInfo.html#a62103956be0a0a61539108e7dec05ba2", null ]
];