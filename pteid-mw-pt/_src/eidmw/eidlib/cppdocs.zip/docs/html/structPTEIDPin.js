var structPTEIDPin =
[
    [ "flags", "structPTEIDPin.html#a35277fb0078d7a8861ea32f4bc95b663", null ],
    [ "id", "structPTEIDPin.html#a293742b46c1eb81fde80682394d92ec4", null ],
    [ "label", "structPTEIDPin.html#ab91de9c11ff68adfb8ff082719700c19", null ],
    [ "longUsage", "structPTEIDPin.html#a969d1198552732182c5ebb8a166ea856", null ],
    [ "pinType", "structPTEIDPin.html#a9cb67e5cd4aa10a260695160d90193d0", null ],
    [ "shortUsage", "structPTEIDPin.html#aa39024bee123d541d699f12cadcf1e37", null ],
    [ "triesLeft", "structPTEIDPin.html#a164283622d06a7c5036ee61dcb1d5c9b", null ],
    [ "usageCode", "structPTEIDPin.html#a25da3c07cb6afc327fa167276b536bd4", null ]
];