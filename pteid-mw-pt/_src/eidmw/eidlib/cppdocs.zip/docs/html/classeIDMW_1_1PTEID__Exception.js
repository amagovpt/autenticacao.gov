var classeIDMW_1_1PTEID__Exception =
[
    [ "PTEID_Exception", "classeIDMW_1_1PTEID__Exception.html#a06a1055abc3959b6f6f7c997d72ecd82", null ],
    [ "~PTEID_Exception", "classeIDMW_1_1PTEID__Exception.html#aab8b7e6e0288388b8e841d44c3ef56fd", null ],
    [ "GetError", "classeIDMW_1_1PTEID__Exception.html#a3b2491c5c61e3e7081ebbea6fabf488a", null ]
];