var structPTEIDPins =
[
    [ "pins", "structPTEIDPins.html#a7f9fd245ed768d46c10c15ce4f953823", null ],
    [ "pinsLength", "structPTEIDPins.html#a56fe3293b8fdb104f293c2f0503cac15", null ]
];