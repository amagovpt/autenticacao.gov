var classeIDMW_1_1PTEID__ReaderContext =
[
    [ "~PTEID_ReaderContext", "classeIDMW_1_1PTEID__ReaderContext.html#a033d654483a0a988618ea24014d61d40", null ],
    [ "BeginTransaction", "classeIDMW_1_1PTEID__ReaderContext.html#aaa7f66aa129ae76fd31de2421b5f7ebb", null ],
    [ "EndTransaction", "classeIDMW_1_1PTEID__ReaderContext.html#a4ad06e9aa962219692edb593474a7f47", null ],
    [ "getCard", "classeIDMW_1_1PTEID__ReaderContext.html#a7f7cdf61e9ca03f93431ca66ef602234", null ],
    [ "getCardType", "classeIDMW_1_1PTEID__ReaderContext.html#a9a21152f6e6b4843eefd34f371b34ccc", null ],
    [ "getEIDCard", "classeIDMW_1_1PTEID__ReaderContext.html#a382ffdfff1de91cd6a8b3da6c9744f41", null ],
    [ "getName", "classeIDMW_1_1PTEID__ReaderContext.html#a9c193c3894a9139a4a11474ee315c8ac", null ],
    [ "isCardChanged", "classeIDMW_1_1PTEID__ReaderContext.html#a683c3220d7345512bfd764f0297d3fe9", null ],
    [ "isCardPresent", "classeIDMW_1_1PTEID__ReaderContext.html#a30c605ea276efff3a066bb1fe99a52cf", null ],
    [ "isPinpad", "classeIDMW_1_1PTEID__ReaderContext.html#a54033aa60b4d59552d04a3066a6b0004", null ],
    [ "releaseCard", "classeIDMW_1_1PTEID__ReaderContext.html#a7ce15b1a8427ed06851a305e983ef6cc", null ],
    [ "SetEventCallback", "classeIDMW_1_1PTEID__ReaderContext.html#ad05d83b3727da93cdd659e47beb8bf65", null ],
    [ "StopEventCallback", "classeIDMW_1_1PTEID__ReaderContext.html#a1bb00ffea2da688f549f3287e40ea61c", null ],
    [ "PTEID_ReaderSet::getReader", "classeIDMW_1_1PTEID__ReaderContext.html#aa11fd838389903c8904d6a943344a020", null ]
];